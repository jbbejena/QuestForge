# WWII Text Adventure Game

## Overview

This is a mobile-optimized, text-based WWII adventure game built with Flask. Players create soldiers with customizable attributes (name, rank, class, weapon) and embark on various missions with different difficulty levels. The game features AI-powered storytelling through OpenAI integration for dynamic narrative generation, turn-based combat mechanics, and a persistent scoring system. The application is designed as a Progressive Web App (PWA) with mobile-first responsive design, touch optimizations, and offline capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Vanilla JavaScript with mobile-first responsive CSS
- **UI Pattern**: Server-side rendered templates with progressive enhancement
- **Mobile Optimization**: Touch handlers, gesture support, and PWA manifest for app-like experience
- **Styling**: CSS custom properties with military-themed color scheme and component-based design
- **Templates**: Jinja2 templating with modular HTML structure (base.html, index.html, missions.html, play.html)

### Backend Architecture
- **Framework**: Flask with session-based state management
- **Architecture Pattern**: MVC with route handlers, template rendering, and in-memory data storage
- **Game Logic**: Turn-based system with character progression, mission selection, and combat mechanics
- **AI Integration**: Optional OpenAI API integration for dynamic story generation with fallback to static content
- **Configuration**: Environment variable-based configuration with .env file support

### Data Storage
- **Session Storage**: Flask sessions for player state, game progress, and statistics
- **In-Memory Storage**: Static game data (missions, ranks, classes, weapons) stored in Python dictionaries
- **No Database**: Simple file-based configuration without persistent database storage

### Authentication and Authorization
- **Session Management**: Flask session handling with configurable secret keys
- **No User Authentication**: Single-player game without user accounts or login system
- **State Persistence**: Game state maintained through browser sessions only

## External Dependencies

### Core Dependencies
- **Flask 3.0.2**: Web framework for routing, templating, and session management
- **python-dotenv 1.0.1**: Environment variable management for configuration
- **OpenAI 1.35.14**: Optional AI integration for dynamic story generation

### Frontend Libraries
- **Font Awesome 6.0.0**: Icon library for UI elements and game symbols
- **No JavaScript Frameworks**: Vanilla JavaScript for mobile optimizations and touch handling

### Infrastructure
- **Replit Platform**: Hosting environment with Nix-based dependency management
- **PWA Support**: Web app manifest for mobile installation and offline capabilities
- **No External Database**: Self-contained application without external data dependencies

### Optional Integrations
- **OpenAI API**: Story generation service with graceful degradation when unavailable
- **Environment Configuration**: Flexible setup supporting both development and production environments